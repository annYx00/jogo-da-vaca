let Fundo;
let imagemCarro;
let imagemCarro1;
let imagemCarro2;
let imagemAtor;


 function preload(){
  Fundo = loadImage("imagens/estrada.png");
  imagemCarro = loadImage("imagens/mercedes.jpg");
   imagemCarro1 = loadImage("imagens/preto.jpg");
   imagemCarro2 = loadImage("imagens/magenta.png");
   imagemAtor = loadImage("imagens/ator-1.png");
  imagemCarros = [imagemCarro, imagemCarro1, imagemCarro2,imagemCarro, imagemCarro1, imagemCarro2];   
  }